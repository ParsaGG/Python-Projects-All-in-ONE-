cd
cd
exit
