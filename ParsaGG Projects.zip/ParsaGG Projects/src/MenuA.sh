echo ' 
 [ 01 ] >> Back To MainMenu  -  Back to MainMenu 
 [ 02 ] >> Reboot system  -  Reboot All tools
 [ 03 ] >> Exit System  -  log out system'|lolcat -p 1.0 -a -d 10 -s 30.0

