echo '
  01) ~ Information Gathering:  -  Collects information from database
  02) ~ Exploitation Tools:  -  selection of tools for operation and hacking
  03) ~ Sniffing and Spoofing:  -  Tools for forgery of data and databases
  04) ~ Web Attack Tool:  -  Tools for hacking websites and servers
  05) ~ Cam Hacking Tool:  -  Tools for hacking cams and front camera
  06) ~ Remote Trojan RAT:  -  Utilities for creating RAT virus
      ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  
  07) ~ SQL injection Tool:  -  Tools for creating viruses
  08) ~ SocialMedia Hacking:  -  Tools for hacking social networks
  09) ~ SMS-spaming Tools:  -  Utilities for spam and anonymous SMS
  10) ~ Vulnerability Analysis:  -  Systems for vulnerability analysis
  11) ~ DarkSearch Tool:  -  Tools for Secret and Onion search 
  12) ~ Phishing And IpHack:  -  Tools for phishing and fake websites
  13) ~ Passworld Attack:  -  Utilities for cracking passwords
  14) ~ Wordlist Generator:  -  Tools for Genering Worldlist
  15) ~ XSS Attack Tools:  -  Utilities for Attacking XSS
      ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  ⁣⁣  ⁣⁣ 
  16) ~ Other tools:  -  Separate and other tools for hacking
  17) ~ Terminal Panel:  -  Termux control and special features
  18) ~ System Settings:  -  AllHackingTools control and special features
  19) ~ System License:  -  View A AllHackingTools License =  License
  20) ~ Update System:  -  Update system and all tools & menu and more utilitys
  21) ~ About System:  -  View system information and developer
  22) ~ Exit System:  -  Log out of the AllHackingTools system '|lolcat -p 3.0
