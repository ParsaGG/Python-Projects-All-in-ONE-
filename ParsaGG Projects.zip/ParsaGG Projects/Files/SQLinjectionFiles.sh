apt-get install git
apt-get install python
cd
cd
cd AllHackingTools
git clone https://github.com/ZechBron/zVirus-Gen
cd zVirus-Gen
pkg install git -y
pkg install wget -y
pkg install curl -y
cd
cd
cd AllHackingTools
git clone https://github.com/UndeadSec/Debinject.git
cd Debinject
cd
cd AllHackingTools
git clone https://github.com/Terror696/Vitus2.0
cd Vitus2.0
apt-get install python 2.x
apt-get install dpkg
apt-get install dpkg-deb
cd AllHackingTools 
cd Files
cd 
cd AllHackingTools
git clone https://github.com/mishakorzik/Infect
cd Infect
bash install.sh
cd
cd
cd AllHackingTools
