cd
cd AllHackingTools
git clone https://github.com/ciku370/hasher
cd
cd
cd AllHackingTools
git clone https://github.com/thamahaxor/hasherdoid
cd hasherdoid
chmod +x hasherdotid.py
cd
cd
cd AllHackingTools
git clone https://github.com/ciku370/hash-generator
cd hash-generator
cd
cd
cd AllHackingTools
git clone https://github.com/s0md3v/Hash-Buster
cd
cd
cd AllHackingTools
