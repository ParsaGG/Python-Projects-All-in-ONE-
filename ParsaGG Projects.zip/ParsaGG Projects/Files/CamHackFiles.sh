apt-get install git
apt-get install python
cd
cd AllHackingTools
git clone https://github.com/AngelSecurityTeam/Cam-Hackers
pip3 install requests
pip3 install colorama
cd Cam-Hackers
cd
cd AllHackingTools
git clone https://github.com/noob-hackers/grabcam
cd 
ls
cd grabcam
cd 
cd AllHackingTools 
git clone https://github.com/Devil-Tigers/CamHack.git
cd CamHack
chmod +x *
cd 
cd 
cd AllHackingTools
