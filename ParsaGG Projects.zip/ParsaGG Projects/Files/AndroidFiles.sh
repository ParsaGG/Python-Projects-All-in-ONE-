cd
cd AllHackingTools
git clone https://github.com/knassar702/pyshell
cd Pyshell
cd
cd AllHackingTools
git clone https://github.com/kinghacker0/WishFish
cd wishfish
cd 
cd AllHackingTools
git clone https://github.com/JasonJerry/lockphish
cd lockphish
cd
cd
cd AllHackingTools
git clone https://github.com/HatBashBR/HatCloud
cd
cd
cd AllHackingTools
