apt install unstable-repo
apt install telegram-cli
cd
cd
cd AllHackingTools
git clone https://github.com/adi1090x/termux-style
cd termux-style
./install
clear
cd
cd
cd AllHackingTools
git clone https://github.com/laraib07/TermuxBackupTools
cd
cd
cd AllHackingTools
git clone https://github.com/mishakorzik/qiq
cd qiq
bash install.sh
cd
cd
cd AllHackingTools
