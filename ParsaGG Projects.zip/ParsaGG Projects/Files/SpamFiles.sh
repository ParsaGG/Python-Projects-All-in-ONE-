apt install future
apt install paramiko
apt install pysnmp
apt install pycrypto
cd
cd AllHackingTools
pip install -r requirements.txt
pip install requests colorama
git clone https://github.com/3UMOBKA/SMS-Bomber-300-Free
cd AllHackingTools
git clone https://github.com/anubhavanonymous/XLR8_BOMBER
cd
cd AllHackingTools
git clone https://github.com/MaksPV/AresBomb
cd 
cd AllHackingTools
git clone https://github.com/HACK3RY2J/Anon-SMS.git
cd Anon-SMS
cd
cd AllHackingTools 
cd Files
cd 
cd AllHackingTools
git clone https://github.com/FSystem88/spymer
pkg install dos2unix
pip install requests colorama proxyscrape
cp ~/spymer/spammer.py $PREFIX/bin/spymer
dos2unix $PREFIX/bin/spymer
chmod -R 777 ~/spymer
chmod 777 /bin/spymer
cd
cd
cd AllHackingTools
git clone https://github.com/TheSpeedX/TBomb.git
cd TBomb
cd
cd
cd AllHackingTools
git clone https://github.com/batiscuff/duplo-bomber
cd duplo-bomber
pip install -r requirements.txt
cd
cd
cd AllHackingTools
git clone https://github.com/mishakorzik/anonymousSMS
cd anonymousSMS
bash setup.sh
cd
cd
cd AllHackingTools
