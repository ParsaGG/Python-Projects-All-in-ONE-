<?php
$white  = "\033[37m";
$orange = "\033[33m";
$green  = "\033[32m";
$red    = "\033[31m";
$cyan   = "\033[36m";
$cln    = "\e[0m";
$bold   = "\e[1m";

echo $white . "  \n";
echo $cyan . "╔bugs   › report bugs \n";
echo $cyan . "║debug  › developer mode \n";
echo $cyan . "║build  › build system \n";
echo $cyan . "║test   › testing code & system \n";
echo $cyan . "╚script › new code programing \n";

echo $white . "  \n";
echo $white . "—";
echo $orange . " New Features: \n";
echo $white . "  \n";
echo $white . "-";
echo $orange . " 53a9007";
echo $white . " [";
echo $red . "bugs";
echo $white . "]";
echo $white . " A bug in the";
echo $green . " Termux-Banner system has now been fixed";
echo $white . "!";

echo $white . "  \n";
echo $white . "-";
echo $orange . " 10a0509";
echo $white . " [";
echo $red . "bugs";
echo $white . "]";
echo $white . " Many faults have been fixed and now the";
echo $green . " system works better";
echo $white . "!";

echo $white . "  \n";
echo $white . "-";
echo $orange . " 5we0011";
echo $white . " [";
echo $red . "debug";
echo $white . "]";
echo $white . " A new";
echo $green . " debug mode has now been added";
echo $white . " for testing and debugging";
echo $white . "!";

echo $white . "  \n";
echo $white . "-";
echo $orange . " 068q068";
echo $white . " [";
echo $red . "debug";
echo $white . "]";
echo $white . " Now when the system is malfunctioning it can be";
echo $green . " fixed through debug mode";
echo $white . "! \n";

echo $white . "-";
echo $orange . " 11a6201";
echo $white . " [";
echo $red . "build";
echo $white . "]";
echo $white . " yet the AllHackingTools system has been";
echo $green . " optimized";
echo $white . "!";
echo $white . "  \n";
echo $white . "  \n";
echo $white . "—";
echo $orange . " New Scripts: \n";
echo $white . "  \n";

echo $white . "-";
echo $orange . " 1t200e6";
echo $white . " [";
echo $red . "script";
echo $white . "]";
echo $white . " AllHackingTools still";
echo $green . " uses php";
echo $white . "!";

echo $white . "  \n";
echo $white . "-";
echo $orange . " 4y00730";
echo $white . " [";
echo $red . "script";
echo $white . "]";
echo $white . " AllHackingTools is";
echo $green . " still improved";
echo $white . "!";

echo $white . "  \n";
echo $white . "-";
echo $orange . " 1sys220";
echo $white . " [";
echo $red . "script";
echo $white . "]";
echo $white . " now text words will";
echo $green . " use php";
echo $white . " instead of shell";
echo $white . "!";
echo $white . "  \n";
echo $white . "  \n";
echo $white . "—";
echo $orange . " Testing: \n";

echo $white . "  \n";
echo $white . "-";
echo $orange . " 71q8809";
echo $white . " [";
echo $red . "Test";
echo $white . "]";
echo $white . " The system has been";
echo $green . " successfully tested";
echo $white . "!";

echo $white . "  \n";
echo $white . "-";
echo $orange . " 5a8890p";
echo $white . " [";
echo $red . "Test";
echo $white . "]";
echo $white . " Developer mode successfully tested";
echo $green . " successfully tested";
echo $white . " in AllHackingTools"; 
echo $white . "!";

echo $white . "  \n";
echo $white . "-";
echo $orange . " 101u021";
echo $white . " [";
echo $red . "Test";
echo $white . "]";
echo $white . " The system";
echo $green . " successfully works";
echo $white . " stably confirmed by the test"; 
echo $white . "!";

?>
